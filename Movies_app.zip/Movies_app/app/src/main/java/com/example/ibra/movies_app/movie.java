package com.example.ibra.movies_app;

/**
 * Created by Ibra on 3/24/2016.
 */
public class movie {

    public void setMovie_overview(String movie_overview) {
        this.movie_overview = movie_overview;
    }

    public void setMovie_title(String movie_title) {
        this.movie_title = movie_title;
    }

    public void setMovie_rating(Double movie_rating) {
        this.movie_rating = movie_rating;
    }

    public void setMovie_release_date(String movie_release_date) {
        this.movie_release_date = movie_release_date;
    }

    public void setMovie_poster(String movie_poster) {
        this.movie_poster = movie_poster;
    }

    public String getMovie_overview() {
        return movie_overview;
    }

    public String getMovie_poster() {
        return movie_poster;
    }

    public String getMovie_release_date() {
        return movie_release_date;
    }

    public Double getMovie_rating() {
        return movie_rating;
    }

    public String getMovie_title() {
        return movie_title;
    }

    private String movie_overview;
    private String movie_title;
    private Double movie_rating;
    private String movie_release_date;
    private String movie_poster;

    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    public int getMovie_id() {
        return movie_id;
    }

    private int movie_id;
}
