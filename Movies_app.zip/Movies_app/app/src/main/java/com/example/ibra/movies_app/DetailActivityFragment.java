package com.example.ibra.movies_app;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view.
 */
public class DetailActivityFragment extends Fragment {

 static  String trailer="asd";

    public ArrayAdapter<String> traillers_adapter;
    public ArrayAdapter<String> reviews_adapter;
    ArrayList<String> trailler_keys=new ArrayList<>();
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }
    @Override
    public void onCreateOptionsMenu(Menu menu,MenuInflater inflater){
        //inflater.inflate(R.menu.mainactivityfragment, menu);


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();


        if(id==R.id.action_settingss)
        {



            Intent intent=new Intent(getContext(),SettingsActivity.class);

            startActivity(intent);


            return true;}

        return super.onOptionsItemSelected(item);


    }




    public DetailActivityFragment() {
    }
    movie Movie;
    String favorits;
    boolean isfavorit=false;
    Button button;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview= inflater.inflate(R.layout.fragment_detail, container, false);
        try {


            Intent intent = getActivity().getIntent();


            //String test=intent.getStringExtra(Intent.EXTRA_TEXT).toString();
            if (intent.getStringExtra(Intent.EXTRA_TEXT) == null) {
                Bundle b =this.getArguments();

                if(b!=null) {
                    int index =b.getInt("position");
                    Movie = MainActivityFragment.data_list.get(index);
                    Log.v("detailseror","nilllllll2");

                }
                else
                { Movie = MainActivityFragment.data_list.get(0);
                    Log.v("detailseror","nilllllll3");}


            } else
            { int index = Integer.parseInt(intent.getStringExtra(Intent.EXTRA_TEXT));
                Movie = MainActivityFragment.data_list.get(index);
                Log.v("detailseror","nilllllll4");}
            ImageView imageView = (ImageView) rootview.findViewById(R.id.movie_image);

            GetTrailersAndReview trailersAndReviews = new GetTrailersAndReview();
            GetTrailersAndReview trailersAndReviews1 = new GetTrailersAndReview();


            trailersAndReviews.execute("" + Movie.getMovie_id(), "videos");
            Picasso.with(getActivity()).load("http://image.tmdb.org/t/p/w185/" + Movie.getMovie_poster()).into(imageView);
            TextView title_textView = (TextView) rootview.findViewById(R.id.movie_title);
            title_textView.setTextColor(Color.rgb(200, 0, 0));

            title_textView.setText(Movie.getMovie_title());
            TextView overvier_textView = (TextView) rootview.findViewById(R.id.movie_overview);
            overvier_textView.setTextColor(Color.rgb(200, 0, 0));
            overvier_textView.setText(Movie.getMovie_overview());


            TextView rate_textView = (TextView) rootview.findViewById(R.id.movie_rate);
            rate_textView.setTextColor(Color.rgb(200, 0, 0));

            rate_textView.setText(Movie.getMovie_rating().toString());
            TextView rDate_textView = (TextView) rootview.findViewById(R.id.movie_rdate);
            rDate_textView.setTextColor(Color.rgb(200, 0, 0));
            rDate_textView.setText(Movie.getMovie_release_date());

            ArrayList<String> trailler_data = new ArrayList<>();

            traillers_adapter = new ArrayAdapter<String>
                    (getActivity(), R.layout.list_item_traillers, R.id.list_item_trailler_textview, trailler_data);

            final ListView listview = (ListView) rootview.findViewById(R.id.listview_trailler);
            listview.setAdapter(traillers_adapter);
            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    String tr = trailler_keys.get(i);


                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + tr));
                        startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                        Intent intent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse("http://www.youtube.com/watch?v=" + tr));
                        startActivity(intent);
                    }


                }
            });

            trailersAndReviews1.execute("" + Movie.getMovie_id(), "reviews");

            ArrayList<String> reviews_data = new ArrayList<>();

            reviews_adapter = new ArrayAdapter<String>
                    (getActivity(), R.layout.list_item_reviews, R.id.list_item_review_textview, reviews_data);

            final ListView listview2 = (ListView) rootview.findViewById(R.id.listview_reviews);
            listview2.setAdapter(reviews_adapter);

            SharedPreferences rsharedPref = getActivity().getSharedPreferences(
                    getString(R.string.pref_favorit_key), Context.MODE_PRIVATE);
            favorits = rsharedPref.getString(getString(R.string.pref_favorit_key), "");
            //  Log.v("favorit","bbbbbbbbbbbbbbbbbb"+favorits);
            String[] favorits_array = favorits.split(",");

            for (String x : favorits_array) {
                if (x.equals(Movie.getMovie_id() + "")) {
                    Log.v("faaaaa", x + "is favorit" + Movie.getMovie_id());

                    isfavorit = true;
                }
            }

            button = (Button) rootview.findViewById(R.id.favorit);
            button.setBackgroundColor(Color.RED);
            if (isfavorit) {
                button.setBackgroundColor(Color.BLUE);
                button.setText("REMOVE FROM FAVORITS");

                favorits = "";

                for (String x : favorits_array) {
                    if (x.equals(Movie.getMovie_id() + "")) {
                        Log.v("equal", x + "equal" + Movie.getMovie_id());


                    } else {
                        favorits += x + ",";
                        Log.v("notequal", x + "noooootequal" + Movie.getMovie_id());
                    }

                }


            }
            Log.v("faa", "is favorit" + favorits);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Log.v("button", "buttonnnnnnnnnnnn" + favorits);

                    SharedPreferences wsharedPref = getActivity().getSharedPreferences(
                            getString(R.string.pref_favorit_key), Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = wsharedPref.edit();
                    if (!isfavorit) {
                        editor.putString(getString(R.string.pref_favorit_key), favorits + Movie.getMovie_id() + ",");
                        button.setText("REMOVE FROM FAVORITS");
                        button.setBackgroundColor(Color.BLUE);

                    } else {
                        button.setBackgroundColor(Color.RED);
                        editor.putString(getString(R.string.pref_favorit_key), favorits);
                        button.setText("make as favorit");
                    }
                    isfavorit = !isfavorit;
                    // editor.putString("favorits_key", "");

                    editor.commit();
                }
            });
        }
        catch (Exception e)
        {
            Log.v("detailseror",e.toString());

        }

        return rootview;
    }


    public class GetTrailersAndReview extends AsyncTask<String,Void,String[]> {


        @Override
        protected String[] doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            // Will contain the raw JSON response as a string.
            String moviesJsonStr = null;

            try {

                String base_url = "http://api.themoviedb.org/3/movie/" + params[0]+"/"+params[1] + "?api_key=";


                URL url = new URL(base_url);

         //       Log.v("DATA1", url + "");


                // Create the request to OpenWeatherMap, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {

                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                    // But it does make debugging a *lot* easier if you print out the completed
                    // buffer for debugging.
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                moviesJsonStr = buffer.toString();
          //      Log.v("DATA",moviesJsonStr);


            } catch (IOException e) {
         //       Log.e("PlaceholderFragment", "Error ", e);
                // If the code didn't successfully get the weather data, there's no point in attemping
                // to parse it.
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
          //              Log.e("PlaceholderFragment", "Error closing stream", e);
                    }
                }
            }

            try {



                if(params[1].equals("videos"))
                {
                String[] data= gettraillersDataFromJson(moviesJsonStr);
            //    Log.v("aaaaaaaaa","ddddddddddd:"+data[0]);
            //        Log.v("papapa",params[1]);
                return  data;}
                else if(params[1].equals("reviews")) {

                  //  Log.v("aaaaaaaaa","eeeeeeeee:"+data[0]);
                    Log.v("papapa",params[1]);
                    String[] data= getreviewsDataFromJson(moviesJsonStr);

                   return  data;}
                else   Log.v("papapa",params[1]);
            } catch (Exception E) {

                 Log.v("exec",E.toString());


            }





            return null;
        }


        private String[] gettraillersDataFromJson(String moviesJsonStr)
                throws JSONException {
            JSONObject moviesJson = new JSONObject(moviesJsonStr);
            JSONArray moviesArray = moviesJson.getJSONArray("results");
            String[]trailler= new String[moviesArray.length()+1];
            Log.v("lennnnn",""+moviesArray.length());
            trailler[0]="trailler";
            for(int i=1;i<=moviesArray.length();i++)
            {
                trailler[i]=moviesArray.getJSONObject(i-1).getString("key");
                Log.v("value",trailler[i]);
            }
            Log.v("lennnnn",""+trailler.length);
            return trailler;
        }
        private String[] getreviewsDataFromJson(String moviesJsonStr)

                 {

                     try{
            JSONObject moviesJson = new JSONObject(moviesJsonStr);
            JSONArray moviesArray = moviesJson.getJSONArray("results");
            String[]reviews= new String[moviesArray.length()+1];
            Log.v("lennnnn","aaa"+moviesArray.length());
            reviews[0]="reviews";

            for(int i=1;i<=moviesArray.length();i++)
            {
                reviews[i]=moviesArray.getJSONObject(i-1).getString("content");
                Log.v("value",reviews[i]);


            }
            Log.v("lennnnn",""+reviews.length+"asddddddddd"+moviesArray.length());



            return reviews;}
                     catch (Exception e)
                     {
                         Log.v("errrrrrrr",e.toString());
                         return null;
                     }


        }



        protected void onPostExecute(String[] movies) {
            //    super.onPostExecute(strings);
//            Log.v("mmmmm",movies[0]);
            if (movies != null) {
                if (movies[0].equals("trailler")) {


                    traillers_adapter.clear();
                    for (int i=1 ;i< movies.length;i++) {
                        traillers_adapter.add("Trailler"+i);
                        trailler_keys.add(movies[i]);
                    }
                } else if (movies[0].equals("reviews")) {
                    reviews_adapter.clear();
                    for (int i=1 ;i< movies.length;i++) {
                        reviews_adapter.add(movies[i]);
                    }
                }
            }



        }



    }
    }



