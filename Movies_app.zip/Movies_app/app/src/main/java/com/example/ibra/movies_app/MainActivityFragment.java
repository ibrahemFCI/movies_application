package com.example.ibra.movies_app;

import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment  {

    public static ArrayList<movie> data_list = new ArrayList<>();
    public static GridView gridview;
    public static String[] img_urls2 =new String[0];
    public static ImageAdapter im;
    boolean empty_favorit;
    // public ArrayAdapter<String> data_adapter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //inflater.inflate(R.menu.mainactivityfragment, menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_refresh) {
         //  ImageAdapter im2 = new ImageAdapter(getActivity(), img_urls2);
        //   gridview.setAdapter(null);
            gridview.setAdapter(im);
            updata_data();
//            img_urls2 = new String[data_list.size()];
//
//            movie m = new movie();
//
//            for (int i = 0; i < data_list.size(); i++) {
//                m = data_list.get(i);
//                img_urls2[i] = m.getMovie_poster();
//                // Log.v("DDDDD123",m.getMovie_title());
//
//            }
          //  im.notifyDataSetChanged();
           // gridview.setAdapter(new ImageAdapter(getActivity(), img_urls2));


        }

        if (id == R.id.action_setting) {

            // Toast.makeText(getActivity(),""+item.getItemId()+"aaa"+R.id.action_setting,Toast.LENGTH_LONG).show();
            // update_weather();

            Intent intent = new Intent(getContext(), SettingsActivity.class);

            startActivity(intent);

            // startActivity(new Intent(getActivity(),Settings.class));

            return true;
        }

        return super.onOptionsItemSelected(item);


    }


    public MainActivityFragment() {
    }
    View rootviwe;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
         rootviwe = inflater.inflate(R.layout.fragment_main, container, false);
        gridview = (GridView) rootviwe.findViewById(R.id.gridView);

        im = new ImageAdapter(getActivity(), img_urls2);
        gridview.setAdapter(im);

        // Picasso.with(getActivity()).load("http://i.imgur.com/DvpvklR.png").into((ImageView)rootviwe.findViewById(R.id.movie_image_item1));
/*
        data_adapter=new ArrayAdapter<ImageView>
                (getActivity(),gridview,R.id.movie_image_item,Picasso.with(getActivity()).load("http://i.imgur.com/DvpvklR.png").into((ImageView)rootviwe.findViewById(R.id.movie_image_item)));
        gridview.setAdapter(data_adapter);*/
       /* String[] img_urls={"nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg ","nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg ",
                "nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg ","nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg "};

        gridview.setAdapter(new ImageAdapter(getActivity(), img_urls));*/


        //  GetMoviesData mdata=new GetMoviesData();
        //   mdata.execute("popular");
        // Log.v("DDDDD",data_list.size()+"dddddddddddd");
     //   updata_data();
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Toast.makeText(getActivity(), data_adapter.getItem(i),Toast.LENGTH_SHORT).show();
              //  String movie = data_list.get(i).getMovie_title();

                Display display = getActivity().getWindowManager().getDefaultDisplay();
                int screenWidth = display.getWidth();
                int screenHeight = display.getHeight();
               // if (rootviwe.findViewById(R.id.fragment_details_layout) != null) {
                if(MainActivity.istablet)
                {






                    DetailActivityFragment detailsFragment = new DetailActivityFragment();
                    Bundle args = new Bundle();
                    args.putInt("position", i);
                    detailsFragment.setArguments(args);

                   // detailsFragment.setArguments(getIntent().getExtras());
                    Log.v("tappp","tapppp");
                   // FragmentTransaction transaction=getActivity().getSupportFragmentManager().beginTransaction();
                   getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_details_layout,detailsFragment)
                           .addToBackStack(null).commit();



//
//                    getActivity().getSupportFragmentManager().beginTransaction()
//                            .add(R.id.fragment_details_layout, detailsFragment).commit();

                }

else {

                    Intent intent = new Intent(getContext(), DetailActivity.class).putExtra(Intent.EXTRA_TEXT, i + "");

                    startActivity(intent);
                }
            }
        });


        return rootviwe;
    }



    @Override

    public void onStart() {

        super.onStart();
        gridview.setAdapter(null);
        gridview.setAdapter(im);
          updata_data();
       // Log.v("staet","starrrrrrrrrrrrrrrrrrt");


    }
    String favorits;
    public void updata_data() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String order_type = prefs.getString(getString(R.string.pref_order_key), getString(R.string.pref_order_default));
        if (order_type.equals("Favorits")) {
            gridview.clearAnimation();
            if(data_list.size()>0)
                empty_favorit=false;
            else
            empty_favorit=true;
         //   data_list.clear();
            GetMovies_Favorits movies_favorits;


           // SharedPreferences rsharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);




            SharedPreferences rsharedPref = getActivity().getSharedPreferences(
                    getString(R.string.pref_favorit_key), Context.MODE_PRIVATE);
            favorits = rsharedPref.getString(getString(R.string.pref_favorit_key), null);
            Log.v("favorit", "aaaaaaaaaaaaaaaaaaaaaaavcv" + favorits);
            if (favorits != null&& !favorits.equals("")) {
                String[] favorits_array = favorits.split(",");
                for (String x : favorits_array) {
                    Log.v("favorit", "aaaaaaaaaaaaaaaaaaaaaaa" + x);
                    if (!x.equals(",")) {
                        try {
                            movies_favorits = new GetMovies_Favorits();
                            movies_favorits.execute(x);
                        }
                        catch (Exception e)
                        {
                            Log.v("exxxxxxx",e.toString());
                        }

                    }
                }
                im.setUrls(data_list);

            }

            else Log.v("nillllllllll","nullllllllllllll");
        } else {
                GetMoviesData mdata = new GetMoviesData();
                mdata.execute(order_type);
                // Log.v("size", data_list.size() + "");
            }




    }




    public class GetMovies_Data extends AsyncTask<String, Void, movie[]> {
        @Override
        protected movie[] doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            // Will contain the raw JSON response as a string.
            String moviesJsonStr = null;

            try {

                String base_url = "http://api.themoviedb.org/3/movie/" + params[0] + "?api_key=";


                URL url = new URL(base_url);

                Log.v("DATA1", url + "");


                // Create the request to OpenWeatherMap, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {

                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                    // But it does make debugging a *lot* easier if you print out the completed
                    // buffer for debugging.
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                moviesJsonStr = buffer.toString();
                //   Log.v("DATA",moviesJsonStr);


            } catch (IOException e) {
                Log.e("PlaceholderFragment", "Error ", e);
                // If the code didn't successfully get the weather data, there's no point in attemping
                // to parse it.
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("PlaceholderFragment", "Error closing stream", e);
                    }
                }
            }

            try {

                return getMoviesDataFromJson(moviesJsonStr);
            } catch (Exception E) {

                // Log.v("exec",E.toString());


            }


            return null;
        }


        private movie[] getMoviesDataFromJson(String moviesJsonStr)
                throws JSONException {
            int numDays = 0;

            // These are the names of the JSON objects that need to be extracted.
            final String results = "results";
            final String release_date = "release_date";
            final String original_title = "original_title";
            final String overview = "overview";
            final String vote_average = "vote_average";
            final String poster_path = "poster_path";
            final String movie_id = "id";

            JSONObject moviesJson = new JSONObject(moviesJsonStr);
            JSONArray moviesArray = moviesJson.getJSONArray(results);


            movie[] resultStrs = new movie[moviesArray.length()];
            for (int i = 0; i < moviesArray.length(); i++) {
                // For now, using the format "Day, description, hi/low"
                movie movie_data = new movie();

                // Get the JSON object representing the day
                JSONObject movieJson = moviesArray.getJSONObject(i);
                movie_data.setMovie_id(movieJson.getInt(movie_id));
                movie_data.setMovie_overview(movieJson.getString(overview));
                movie_data.setMovie_poster(movieJson.getString(poster_path));
                movie_data.setMovie_rating(movieJson.getDouble(vote_average));
                movie_data.setMovie_release_date(movieJson.getString(release_date));
                movie_data.setMovie_title(movieJson.getString(original_title));


                resultStrs[i] = movie_data;
                // Log.v("asddd",""+resultStrs.length);
            }

            for (movie s : resultStrs) {
                //  Log.v("Forecast entry: ", "" + s.getMovie_title());
            }
            Log.v("titlt", resultStrs[19].getMovie_title() + "///" + moviesArray.length());
            return resultStrs;

        }

        protected void onPostExecute(movie[] movies) {
            // super.onPostExecute(strings);
            if (movies != null) {

                data_list.clear();
                for (movie m : movies) {
                    data_list.add(m);
                }

                im.setUrls(data_list);


            } else {
                Log.v("DDDDD123", "empty");
            }

        }


    }







    public class GetMovies_Favorits extends AsyncTask<String, Void, movie> {
        @Override
        protected movie doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            // Will contain the raw JSON response as a string.
            String moviesJsonStr = null;

            try {

                String base_url = "http://api.themoviedb.org/3/movie/" + params[0] + "?api_key=";
                Log.v("urllllll",base_url);


                URL url = new URL(base_url);

                //Log.v("DATA1", url + "");


                // Create the request to OpenWeatherMap, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {

                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                    // But it does make debugging a *lot* easier if you print out the completed
                    // buffer for debugging.
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                moviesJsonStr = buffer.toString();
                //   Log.v("DATA",moviesJsonStr);


            } catch (IOException e) {
                Log.e("PlaceholderFragment", "Error ", e);
                Log.v("Errrrrrrr",e.toString());
                // If the code didn't successfully get the weather data, there's no point in attemping
                // to parse it.
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("PlaceholderFragment", "Error closing stream", e);
                    }
                }
            }

            try {

                return getMoviesDataFromJson(moviesJsonStr);
            } catch (Exception E) {

                // Log.v("exec",E.toString());


            }


            return null;
        }


        private movie getMoviesDataFromJson(String moviesJsonStr)
                throws JSONException {
            int numDays = 0;

            // These are the names of the JSON objects that need to be extracted.
            final String results = "results";
            final String release_date = "release_date";
            final String original_title = "original_title";
            final String overview = "overview";
            final String vote_average = "vote_average";
            final String poster_path = "poster_path";
            final String movie_id = "id";

            JSONObject movieJson = new JSONObject(moviesJsonStr);
         //   JSONArray moviesArray = moviesJson.getJSONArray(results);


//            movie[] resultStrs = new movie[moviesArray.length()];
//            for (int i = 0; i < moviesArray.length(); i++) {
//                // For now, using the format "Day, description, hi/low"
                movie movie_data = new movie();

                // Get the JSON object representing the day
               // JSONObject movieJson = moviesArray.getJSONObject(i);
                movie_data.setMovie_id(movieJson.getInt(movie_id));
                movie_data.setMovie_overview(movieJson.getString(overview));
                movie_data.setMovie_poster(movieJson.getString(poster_path));
                movie_data.setMovie_rating(movieJson.getDouble(vote_average));
                movie_data.setMovie_release_date(movieJson.getString(release_date));
                movie_data.setMovie_title(movieJson.getString(original_title));


               // resultStrs[i] = movie_data;
                // Log.v("asddd",""+resultStrs.length);
//            }
//
//            for (movie s : resultStrs) {
//                //  Log.v("Forecast entry: ", "" + s.getMovie_title());
//            }
           // Log.v("titlt", resultStrs[19].getMovie_title() + "///" + moviesArray.length());
            return movie_data;

        }

        protected void onPostExecute(movie movies) {
            // super.onPostExecute(strings);
          if (!empty_favorit) {

            data_list.clear();
              empty_favorit=true;
//                for (movie m : movies) {

                }
            data_list.add(movies);




//            } else {
//                Log.v("DDDDD123", "empty");
//            }

        }


    }







}

