package com.example.ibra.movies_app;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Ibra on 4/14/2016.
 */
public class GetTrailersAndReviews extends AsyncTask<String,Void,String> {
//    @Override
//    protected Void doInBackground(Void... voids) {
//        return null;
//    }
static String trailer;

    @Override
    protected String doInBackground(String... params) {
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;

        // Will contain the raw JSON response as a string.
        String moviesJsonStr = null;

        try {

            String base_url = "http://api.themoviedb.org/3/movie/" + params[0]+"/"+params[1] + "?api_key=6b8de5b3c9aae9443ed132bc75d0b2a5";


            URL url = new URL(base_url);

            //Log.v("DATA1", url + "");


            // Create the request to OpenWeatherMap, and open the connection
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            // Read the input stream into a String
            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if (inputStream == null) {

                return null;
            }
            reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line + "\n");
            }

            if (buffer.length() == 0) {
                // Stream was empty.  No point in parsing.
                return null;
            }
            moviesJsonStr = buffer.toString();
              Log.v("DATA",moviesJsonStr);


        } catch (IOException e) {
            Log.e("PlaceholderFragment", "Error ", e);
            // If the code didn't successfully get the weather data, there's no point in attemping
            // to parse it.
            return null;
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("PlaceholderFragment", "Error closing stream", e);
                }
            }
        }

        try {

           String data= getMoviesDataFromJson(moviesJsonStr);
            Log.v("aaaaaaaaa",data);
            return  data;
        } catch (Exception E) {

            // Log.v("exec",E.toString());


        }





        return null;
    }


    private String getMoviesDataFromJson(String moviesJsonStr)
            throws JSONException {
        int numDays = 0;

        // These are the names of the JSON objects that need to be extracted.
//        final String results = "results";
//        final String release_date = "release_date";
//        final String original_title = "original_title";
//        final String overview = "overview";
//        final String vote_average = "vote_average";
//        final String poster_path = "poster_path";
//        final String movie_id = "id";



        JSONObject moviesJson = new JSONObject(moviesJsonStr);
        JSONArray moviesArray = moviesJson.getJSONArray("results");
        String trailler= moviesArray.getJSONObject(0).getString("key");
       // trailer=trailler+"ibrahem";

        //Log.v("trailer",trailer);

        return trailler;



//        movie[] resultStrs = new movie[moviesArray.length()];
//        for (int i = 0; i < moviesArray.length(); i++) {
//            // For now, using the format "Day, description, hi/low"
//            movie movie_data = new movie();
//
//            // Get the JSON object representing the day
//            JSONObject movieJson = moviesArray.getJSONObject(i);
//
//
//            // description is in a child array called "weather", which is 1 element long.
//            // JSONObject weatherObject = movieJson.getJSONArray(OWM_WEATHER).getJSONObject(0);
//            movie_data.setMovie_id(movieJson.getInt(movie_id));
//            movie_data.setMovie_overview(movieJson.getString(overview));
//            movie_data.setMovie_poster(movieJson.getString(poster_path));
//            movie_data.setMovie_rating(movieJson.getDouble(vote_average));
//            movie_data.setMovie_release_date(movieJson.getString(release_date));
//            movie_data.setMovie_title(movieJson.getString(original_title));
//
//
//            resultStrs[i] = movie_data;
//            // Log.v("asddd",""+resultStrs.length);
//        }
//
//        for (movie s : resultStrs) {
//            //  Log.v("Forecast entry: ", "" + s.getMovie_title());
//        }
//        Log.v("titlt", resultStrs[19].getMovie_title() + "///" + moviesArray.length());
//        return resultStrs;

    }


    protected void onPostExecute(String movies) {
     //    super.onPostExecute(strings);


          //  MainActivityFragment.im.setUrls(MainActivityFragment.data_list);

//
//            MainActivityFragment.img_urls2 = new String[MainActivityFragment.data_list.size()];
//
//            movie m = new movie();
//
//            for (int i = 0; i < MainActivityFragment.data_list.size(); i++) {
//                m = MainActivityFragment.data_list.get(i);
//                MainActivityFragment.img_urls2[i] = m.getMovie_poster();
//                //  Log.v("DDDDD123",m.getMovie_title());
//
//            }
//
//
//            MainActivityFragment.im.notifyDataSetChanged();
//            Log.v("DDDDD", MainActivityFragment.img_urls2.length + "");
//        } else {
//            Log.v("DDDDD123", "empty");
//        }
        DetailActivityFragment.trailer=movies;

    }




}
