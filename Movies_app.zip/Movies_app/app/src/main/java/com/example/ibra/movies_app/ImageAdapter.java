package com.example.ibra.movies_app;

import android.content.Context;
import android.graphics.Movie;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Ibra on 3/23/2016.
 */
public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    private static String[] img_url;

    public ImageAdapter(Context c,String[] url) {
        mContext = c;
        img_url=url;
    }

    public int getCount() {
     //   Log.v ("count",""+img_url.length);
        return img_url.length;

    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {

            imageView = new ImageView(mContext);

        } else {
            imageView = (ImageView) convertView;
        }
        Picasso.with(mContext).load("http://image.tmdb.org/t/p/w185/"+img_url[position]).into(imageView);
       // Log.v("DDDDD123", img_url[position]);


        return imageView;
    }


    void setUrls(ArrayList<movie> urls){



            img_url = new String[urls.size()];

            movie m = new movie();

            for (int i = 0; i < urls.size(); i++) {
                m = urls.get(i);
                img_url[i] = m.getMovie_poster();
              //    Log.v("DDDDD1234",img_url[i]);


            }

    }

}